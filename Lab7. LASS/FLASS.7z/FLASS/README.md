# FLASS Project #

----------

## About FLASS ##
 This is the Project further visualizing your LASS Data onto Freeboard, Thingspeak, Slack on Docker Cloud and Node-RED contributed by [frrut.com](http://frrut.com)
 
## LASS official code##
The configuration setting on configuration.h only. The code is originally from LASS for Linkit One Board, you can also download from official web site for modification too. Please visit [http://frrut.com/flass/](http://frrut.com/flass/ "FLASS") for video tutorials.  

Official LASS
[https://github.com/LinkItONEDevGroup/LASS/tree/master/Device_LinkItOne](https://github.com/LinkItONEDevGroup/LASS/tree/master/Device_LinkItOne)  

## Author ##
Howard howardweng@gmail.com
at [frrut.com](http://frrut.com)

## Video Tutorials ##

Please visit [http://frrut.com/flass/](http://frrut.com/flass/ "FLASS") for video tutorials
